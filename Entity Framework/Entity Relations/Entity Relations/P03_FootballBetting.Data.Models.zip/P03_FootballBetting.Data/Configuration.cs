﻿
namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string ConnectionString =
            @"Server = localhost; Database = FootballBetting; User Id = sa; Password = Stefan@@Peshev";
    }
}
