﻿
namespace P01_StudentSystem.Data.Models.Enumerators
{
    public enum ContentType
    {
        Application = 10,
        Pdf = 20, 
        Zip = 30,
    }
}
