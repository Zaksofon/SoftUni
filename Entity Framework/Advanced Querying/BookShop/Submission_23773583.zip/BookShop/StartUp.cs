﻿using System;
using System.Linq;
using System.Text;
using BookShop.Models.Enums;

namespace BookShop
{
    using Data;
    using Initializer;

    public class StartUp
    {
        public static void Main()
        {
            using (var db = new BookShopContext())
            {
                DbInitializer.ResetDatabase(db);

                string result = GetBooksByAgeRestriction(db, "miNor");
                Console.WriteLine(result);
            }

            string GetBooksByAgeRestriction(BookShopContext context, string command)
            {
                var ageRestriction = Enum.Parse<AgeRestriction>(command, true);

                var bookTitles = context.Books
                    .Where(b => b.AgeRestriction == ageRestriction)
                    .Select(t => new
                    {
                        t.Title
                    })
                    .OrderBy(t => t.Title)
                    .ToArray();

                var sb = new StringBuilder();

                foreach (var title in bookTitles)
                {
                    sb.AppendLine($"{title.Title}");
                }

                return sb.ToString().TrimEnd();
            }
        }
    }
}
