﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=localhost;Database=BookShop;User=sa;Password=Stefan@@Peshev";
    }
}
