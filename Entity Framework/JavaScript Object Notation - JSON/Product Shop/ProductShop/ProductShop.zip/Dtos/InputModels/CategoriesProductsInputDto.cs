﻿
using System.Security.Principal;

namespace ProductShop.Dtos.InputModels
{
    public class CategoriesProductsInputDto
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }

}
