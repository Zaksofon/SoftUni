﻿
namespace ProductShop.Dtos.InputModels
{
    public class UserInputDto
    {
        public string firstName { get; set; }

        public string lastName { get; set; }

        public int? age { get; set; }
    }
}
