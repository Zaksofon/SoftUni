﻿
namespace ProductShop.Dtos.InputModels
{
    public class CategoriesInputDto
    {
        public string Name { get; set; }
    }
}
