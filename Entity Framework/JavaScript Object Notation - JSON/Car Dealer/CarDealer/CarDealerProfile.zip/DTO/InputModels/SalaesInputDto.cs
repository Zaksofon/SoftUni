﻿
namespace CarDealer.DTO.InputModels
{
    public class SalaesInputDto
    {
        public int CarId { get; set; }

        public int CustomerId { get; set; }

        public decimal Discount { get; set; }
    }
}
