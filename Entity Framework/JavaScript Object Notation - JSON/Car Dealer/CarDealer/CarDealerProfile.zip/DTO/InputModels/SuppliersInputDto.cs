﻿

namespace CarDealer.DTO.InputModels
{
    public class SuppliersInputDto
    {
        public string Name { get; set; }

        public bool IsImporter { get; set; }
    }
}
