﻿using System.ComponentModel.DataAnnotations;

namespace Artillery.DataProcessor.ImportDto
{
    public class NestedCuntryImportDto
    {
        [Required]
        public int Id { get; set; }
    }
}
