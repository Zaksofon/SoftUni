﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=localhost;Database=VaporStore;User=sa;Password=Stefan@@Peshev";
	}
}