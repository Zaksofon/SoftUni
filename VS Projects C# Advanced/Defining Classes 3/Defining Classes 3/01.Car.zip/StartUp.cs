﻿using System;

namespace Defining_Classes_3
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car myCar = new Car();

            myCar.Make = "Honda";
            myCar.Model = "CR-V";
            myCar.Year = 2007;

            Console.WriteLine($"Make:{myCar.Make}\nModel: {myCar.Model}\nYear: {myCar.Year}");
        }
    }
}
